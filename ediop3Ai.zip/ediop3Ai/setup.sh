#!/bin/bash

echo "🛠️ Setting up ediop3Ai environment..."

# Detect OS
OS_TYPE="unknown"
if grep -qi "android" /proc/version 2>/dev/null || [ -n "$PREFIX" ] && [ -d "/data/data/com.termux" ]; then
  OS_TYPE="termux"
elif grep -qi "kali" /etc/os-release 2>/dev/null; then
  OS_TYPE="kali"
elif grep -qi "parrot" /etc/os-release 2>/dev/null; then
  OS_TYPE="parrot"
fi

echo "Detected OS: $OS_TYPE"

# System package install based on OS
if [ "$OS_TYPE" = "termux" ]; then
  echo "Running Termux package updates and installs..."
  pkg update && pkg upgrade -y
  pkg install python fftw libsndfile clang make cmake git -y
elif [ "$OS_TYPE" = "kali" ] || [ "$OS_TYPE" = "parrot" ]; then
  echo "Running Debian-based package updates and installs..."
  sudo apt update && sudo apt upgrade -y
  sudo apt install -y python3 python3-pip python3-venv build-essential libsndfile1 ffmpeg portaudio19-dev libffi-dev libssl-dev cmake ninja-build
else
  echo "[WARNING] OS not recognized or unsupported. Please install dependencies manually."
fi

# Check Python3 and pip3 presence
if ! command -v python3 &> /dev/null; then
  echo "[ERROR] Python3 is not installed. Please install it first."
  exit 1
fi

if ! command -v pip3 &> /dev/null; then
  echo "[ERROR] pip3 is not installed. Please install it first."
  exit 1
fi

# Upgrade pip and install Python packages
echo "Installing/upgrading Python packages..."
pip3 install --upgrade pip setuptools wheel
pip3 install rich prompt_toolkit speechrecognition sounddevice numpy pymupdf faiss-cpu sentence-transformers huggingface_hub

# Termux: Build llama_cpp manually
if [ "$OS_TYPE" = "termux" ]; then
  echo "Building llama_cpp from source in Termux..."
  rm -rf llama.cpp
  git clone https://github.com/ggerganov/llama.cpp
  cd llama.cpp
  make
  cd python
  python3 setup.py install --user
  cd ../..
fi

# Prompt user for Hugging Face token
echo ""
echo "🔑 Please enter your Hugging Face token (get it from https://huggingface.co/settings/tokens):"
read -s HF_TOKEN
echo ""

# Log in to Hugging Face CLI using the token
echo "$HF_TOKEN" | huggingface-cli login --token-stdin

# Create models directory
mkdir -p ediop3Ai/models

echo ""
echo "⬇️ Downloading models (this may take some time)..."

huggingface-cli download TheBloke/TinyLlama-1.1B-Chat-v1.0-GGUF --local-dir ./ediop3Ai/models --filename ediop3-fast.gguf
huggingface-cli download TheBloke/Mistral-7B-Instruct-v0.2-GGUF --local-dir ./ediop3Ai/models --filename ediop3-wise.gguf
huggingface-cli download TheBloke/LLaMA-13B-GGUF --local-dir ./ediop3Ai/models --filename ediop3-sage.gguf

echo ""
echo "✅ All downloads finished! Models saved to ediop3Ai/models/"
echo "You can now run your script."

