import os, json, socket
from datetime import datetime
from rich.console import Console
from prompt_toolkit import PromptSession
from llama_cpp import Llama
import speech_recognition as sr
import sounddevice as sd
import numpy as np
import fitz  # PyMuPDF
import faiss
from sentence_transformers import SentenceTransformer

console = Console()
session = PromptSession()
CHAT_DIR = "./chats"
os.makedirs(CHAT_DIR, exist_ok=True)

# Models
MODELS = {
    "ediop3-fast": {"path": "./models/ediop3-fast.gguf", "n_ctx": 1024, "description": "⚡ TinyLLaMA"},
    "ediop3-wise": {"path": "./models/ediop3-wise.gguf", "n_ctx": 2048, "description": "🧠 Mistral"},
    "ediop3-sage": {"path": "./models/ediop3-sage.gguf", "n_ctx": 4096, "description": "📚 LLaMA 13B"},
}
LLMS = {}
EMBED_MODEL = SentenceTransformer('all-MiniLM-L6-v2')

history = []
embedded_texts, embedded_vectors = [], []
faiss_index = None

# Util functions
def has_internet():
    try:
        socket.create_connection(("1.1.1.1", 53), timeout=1)
        return True
    except Exception:
        return False

def format_prompt(history, user_input):
    return "".join(f"[INST] {h['user']} [/INST] {h['assistant']}\n" for h in history) + f"[INST] {user_input} [/INST]"

def list_chats():
    chats = sorted(os.listdir(CHAT_DIR))
    for idx, fname in enumerate(chats):
        console.print(f"[{idx}] {fname}")
    return chats

def save_chat(history, name=None):
    name = name or f"ediop3-chat_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    try:
        with open(os.path.join(CHAT_DIR, name), "w") as f:
            json.dump(history, f, indent=2)
        console.print(f"[bold yellow]Chat saved as:[/bold yellow] {name}")
    except Exception as e:
        console.print(f"[red]Failed to save chat:[/red] {e}")

def load_chat(name):
    try:
        with open(os.path.join(CHAT_DIR, name), "r") as f:
            return json.load(f)
    except Exception as e:
        console.print(f"[red]Failed to load chat:[/red] {e}")
        return []

def record_audio(seconds=10, fs=16000):
    console.print(f"[blue]Recording {seconds}s voice input...[/blue]")
    try:
        audio = sd.rec(int(seconds * fs), samplerate=fs, channels=1, dtype='int16')
        sd.wait()
        return np.squeeze(audio)
    except Exception as e:
        console.print(f"[red]Audio recording failed:[/red] {e}")
        return np.array([], dtype='int16')

def audio_to_text(audio_data, fs=16000):
    if audio_data.size == 0:
        return "[Error] No audio data"
    recognizer = sr.Recognizer()
    try:
        audio = sr.AudioData(audio_data.tobytes(), fs, 2)
        text = recognizer.recognize_google(audio)
        console.print(f"[green]Transcribed:[/green] {text}")
        return text
    except sr.UnknownValueError:
        return "[Unclear audio]"
    except sr.RequestError as e:
        return f"[Error] Speech recognition failed: {e}"

def read_pdf_text(filepath):
    try:
        doc = fitz.open(filepath)
        text = "\n".join(page.get_text() for page in doc)
        doc.close()
        return text.strip()
    except Exception as e:
        return f"[Error] PDF reading failed: {e}"

def add_to_index(text, metadata=None):
    global faiss_index
    try:
        vec = EMBED_MODEL.encode([text])[0]
        embedded_texts.append(text)
        embedded_vectors.append(vec)
        if faiss_index is None:
            faiss_index = faiss.IndexFlatL2(len(vec))
        faiss_index.add(np.array([vec], dtype=np.float32))
    except Exception as e:
        console.print(f"[red]Failed to index text:[/red] {e}")

def search_similar(query, k=3):
    if faiss_index is None or not embedded_vectors:
        return []
    try:
        query_vec = EMBED_MODEL.encode([query])[0].reshape(1, -1)
        distances, indices = faiss_index.search(np.array(query_vec, dtype=np.float32), k)
        return [embedded_texts[i] for i in indices[0] if i < len(embedded_texts)]
    except Exception as e:
        console.print(f"[red]Vector search failed:[/red] {e}")
        return []

def load_models():
    console.print("[bold cyan]Loading ediop3Ai models...[/bold cyan]")
    for name, config in MODELS.items():
        try:
            LLMS[name] = Llama(model_path=config["path"], n_ctx=config["n_ctx"], n_threads=8, use_mlock=True)
            console.print(f"[green]Loaded {name}:[/green] {config['description']}")
        except Exception as e:
            console.print(f"[red]Failed to load {name}:[/red] {e}")

def select_model(prompt):
    wc = len(prompt.split())
    if wc < 10:
        return "ediop3-fast"
    elif wc < 30:
        return "ediop3-wise"
    else:
        return "ediop3-sage" if "ediop3-sage" in LLMS else "ediop3-wise"

# Simple local fallback if models fail
def local_fallback_response(prompt):
    return "I'm currently running in fallback mode. Please try a lighter model or check installations."

# Chat loop
def chat_loop():
    global history
    console.print("\n[bold blue]ediop3Ai ready. Type /help for options.[/bold blue]")

    while True:
        try:
            user_input = session.prompt("You: ").strip()
        except (EOFError, KeyboardInterrupt):
            console.print("\n[red]Exiting...[/red]")
            break

        if user_input.startswith("/"):
            if user_input == "/exit":
                break
            elif user_input == "/save":
                save_chat(history)
            elif user_input == "/chats":
                list_chats()
            elif user_input.startswith("/load"):
                try:
                    idx = int(user_input.split()[1])
                    chats = list_chats()
                    history = load_chat(chats[idx])
                    for h in history:
                        add_to_index(h['user'])
                        console.print(f"[cyan]You:[/cyan] {h['user']}")
                        console.print(f"[magenta]ediop3Ai:[/magenta] {h['assistant']}\n")
                except Exception:
                    console.print("[red]Usage: /load <index>[/red]")
            elif user_input == "/voice":
                audio = record_audio(10)
                user_input = audio_to_text(audio)
                console.print(f"[cyan]You (voice):[/cyan] {user_input}")
            elif user_input.startswith("/pdf"):
                try:
                    path = user_input.split(maxsplit=1)[-1]
                    text = read_pdf_text(path)
                    console.print(f"[bold green]PDF Content:[/bold green]\n{text[:1000]}")
                    user_input = text[:512]
                except Exception:
                    console.print("[red]Usage: /pdf <path>[/red]")
                    continue
            elif user_input.startswith("/recall"):
                try:
                    query = user_input.split(maxsplit=1)[-1]
                    for res in search_similar(query):
                        console.print(f"[dim]↪ {res}[/dim]")
                except Exception:
                    console.print("[red]Usage: /recall <text>[/red]")
                continue
            elif user_input == "/help":
                console.print("""
[bold cyan]ediop3Ai Chat Commands:[/bold cyan]
/exit           Exit chat
/save           Save current chat
/load <n>       Load chat from history
/chats          List saved chats
/voice          Speak into mic (10s)
/pdf <path>     Load and insert PDF text
/recall <text>  Search similar past prompts
/help           Show this help
""")
                continue
            else:
                console.print("[red]Unknown command.[/red]")
                continue

        if not user_input.strip():
            continue

        for context in search_similar(user_input):
            console.print(f"[dim]↩ Recall:[/dim] {context}")

        prompt = format_prompt(history, user_input)
        model_key = select_model(user_input)
        model = LLMS.get(model_key)

        try:
            if model:
                response = model(prompt, max_tokens=256, stop=["[INST]"])
                answer = response["choices"][0]["text"].strip()
            else:
                raise Exception("Model not loaded")
        except Exception as e:
            console.print(f"[red]Error using model {model_key}, using fallback.[/red] ({e})")
            answer = local_fallback_response(prompt)

        console.print(f"[magenta]ediop3Ai ({model_key}):[/magenta] {answer}\n")
        history.append({"user": user_input, "assistant": answer})
        add_to_index(user_input)

# Run
if __name__ == "__main__":
    load_models()
    chat_loop()

